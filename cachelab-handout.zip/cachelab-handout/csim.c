#include "cachelab.h"
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <unistd.h>
#include <getopt.h>

typedef struct {
   int valid_bit;
   uint64_t tag;
   int count;
}cache_line;

static int s, S, E, b, B, t;
char *trace_file;
cache_line * cline; 

void read_common(int argc, char *argv[]) 
{
	char opt;
	while((opt = getopt(argc, argv, "s:E:b:t:")) != -1)
	{
		switch(opt) 
		{
		    case 's':
		        s = atoi(optarg);
		        S = 1 << s;
		        break;
		    case 'E':
		        E = atoi(optarg);
		        break;
		    case 'b':
		        b = atoi(optarg);
		        B = 1 << b;
		        break;
		    case 't':
		        trace_file = optarg;
		        break;
		    default:
		        printf("wrong argument\n");
		        break;
		}
	}
	t = 64 - b - s;
	
}

void del2(uint64_t * addr, int cnt) {
    for(int i = 1; i <= cnt; i++) {
        (*addr) /= 2;
    }
}

uint64_t cal(uint64_t addr, int cnt) {
    uint64_t res = 0;
    for(int i = 1; i <= cnt; i++) {
        res *= 2;
        res += (addr & 1);
        addr >>= 1;
    }
    return res;
}

int cur = 0;
int hit_count = 0, miss_count = 0, eviction_count = 0;

int cachehit(uint64_t group, uint64_t tag) {
    for(int i = 0; i < E; i++) {
        uint64_t no = group * E + i;
        if(cline[no].valid_bit && cline[no].tag == tag) {
            return no;
        }
    }
   
    return -1;
}

uint64_t find_empty(uint64_t group) {
    for(int i = 0; i < E; i++) {
        uint64_t no = group * E + i;
        if(cline[no].valid_bit == 0) {
            return no;
        }
    }
    return -1;
}

uint64_t LUR(uint64_t group) {
    int mi = 100000000;
    uint64_t rno;
    for(int i = 0; i < E; i++) {
        int no = group * E + i;
        if(cline[no].count < mi) {
            mi = cline[no].count;
            rno = no;
        }
    }
    return rno;
}

void cacheop(uint64_t group, uint64_t tag) {
     ++cur;
     uint64_t no;
     if((no = cachehit(group, tag)) != -1) {
         hit_count++;
         //printf(" hit");
     }
     else {
         if((no = find_empty(group)) != -1) {
            miss_count++;
            cline[no].valid_bit = 1;
            cline[no].tag = tag;
            //printf(" missise");
        }
         else {
            no = LUR(group);
            miss_count++;
            eviction_count++;
            cline[no].tag = tag;
            //printf(" missise evict");
        }
    }
    cline[no].count = cur;
}

int main(int argc, char *argv[]) {
    read_common(argc, argv);

    FILE * pFile;
    pFile = fopen(trace_file, "r");

    cline  = (cache_line*) malloc(S * E * sizeof(cache_line));
    char identifier;
    uint64_t address;
    int size;
    while(fscanf(pFile, " %c %lx,%d", &identifier, &address, &size) > 0) 
    {
        //printf("address:%lx\n", address);
        if(identifier == 'I') 
            continue;
        uint64_t group, tag;
        del2(&address, b);
        group = cal(address, s);
        del2(&address, s);
        tag = cal(address, t);
        switch(identifier) {
            case 'L':
            case 'S':
                cacheop(group, tag);
                break;
            case 'M':
                cacheop(group, tag);
                cacheop(group, tag);
                break;
        }
        //printf("\n");
    }
    fclose(pFile);
    free(cline);
	//hit_count, miss_count, eviction_count
    printSummary(hit_count, miss_count, eviction_count);
    return 0;
}
